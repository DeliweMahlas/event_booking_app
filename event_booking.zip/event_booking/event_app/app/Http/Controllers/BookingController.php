<?php

// app/Http/Controllers/BookingController.php
namespace App\Http\Controllers;

use App\Models\Event;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Stripe\Stripe;
use Stripe\PaymentIntent;

class BookingController extends Controller
{
    public function showBookingForm($eventId)
    {
        $event = Event::findOrFail($eventId);
        return view('bookings.create', compact('event'));
    }

    public function storeBooking(Request $request, $eventId)
    {
        $request->validate([
            'number_of_tickets' => 'required|integer|min:1',
            'stripeToken' => 'required|string',
        ]);

        $event = Event::findOrFail($eventId);
        $numberOfTickets = $request->input('number_of_tickets');

        // Calculate total price
        $totalPrice = $event->ticket_price * $numberOfTickets;

        // Create a payment intent
        Stripe::setApiKey(config('services.stripe.secret'));
        $paymentIntent = PaymentIntent::create([
            'amount' => $totalPrice * 100, // amount in cents
            'currency' => 'usd',
            'payment_method' => $request->input('stripeToken'),
            'confirm' => true,
        ]);

        // Save booking details in the database (pseudo-code)
        // Booking::create([
        //     'user_id' => Auth::id(),
        //     'event_id' => $eventId,
        //     'number_of_tickets' => $numberOfTickets,
        //     'payment_status' => 'completed',
        //     'amount_paid' => $totalPrice,
        // ]);

        return redirect()->route('events.index')->with('success', 'Booking confirmed and payment processed.');
    }
}
