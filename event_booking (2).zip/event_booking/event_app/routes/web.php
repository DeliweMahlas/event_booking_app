<?php

use App\Http\Controllers\AuthManager;
use App\Http\Controllers\EventController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\BookingController;
use App\Http\Controllers\PaymentController;
use App\Http\Controllers\CategoryController;
use Illuminate\Support\Facades\Route;


use App\Http\Controllers\HomeController;
Route::get('/', function () {
    return view('welcome');
});
// Home page route
Route::get('/home', [HomeController::class, 'index'])->name('home');
Route::get('/login', [AuthManager::class, 'login'])->name('login');
Route::post('/login', [AuthManager::class, 'loginPost'])->name('login.post');
Route::get('/registration', [AuthManager::class, 'registration'])->name('registration');
Route::post('/registration', [AuthManager::class, 'registrationPost'])->name('registration.post'); 
Route::get('/events', [EventController::class, 'index'])->name('events.index');
Route::get('/events/{id}', [EventController::class, 'show'])->name('events.show');
// Show the form for creating a new event
Route::get('event/create', [EventController::class, 'create'])->name('events.create');

// Store the newly created event
Route::post('event/store', [EventController::class, 'store'])->name('events.store');

// Display all events
Route::get('event/attendeeview', [EventController::class, 'index'])->name('user.userpage');


Route::get('/events/{eventId}/book', [BookingController::class, 'showBookingForm'])->name('bookings.create');
Route::post('/events/{eventId}/book', [BookingController::class, 'storeBooking'])->name('bookings.store');
//Route::post('/events/{id}/book', [BookingController::class, 'store'])->name('booking.store');

// View booking history
Route::get('/bookings', [BookingController::class, 'history'])->name('booking.history');
Route::post('/events/{event}/book', [BookingController::class, 'bookEvent'])->name('events.book');
Route::get('/bookings/manage', [BookingController::class, 'manageBookings'])->name('bookings.manage');
Route::delete('/bookings/{booking}', [BookingController::class, 'cancelBooking'])->name('bookings.cancel');

Route::get('/events/{eventId}/book', [BookingController::class, 'showBookingForm'])->name('bookings.create');
Route::post('/events/{eventId}/book', [BookingController::class, 'storeBooking'])->name('bookings.store');
// Handle booking
Route::post('events/{id}/book', [BookingController::class, 'store'])->name('events.book');
// Admin dashboard
Route::get('/admin/dashboard', [AdminController::class, 'index'])->name('admin.dashboard');

// Manage events and users
Route::get('/admin/events', [AdminController::class, 'manageEvents'])->name('admin.manage.events');
Route::get('/admin/users', [AdminController::class, 'manageUsers'])->name('admin.manage.users');


// Show payment form
Route::get('/payment/{booking}', [PaymentController::class, 'show'])->name('payment.show');

// Process payment
Route::post('/payment/{booking}', [PaymentController::class, 'process'])->name('payment.process');

Route::get('/events/recommendations', [EventController::class, 'recommendEvents'])->name('events.recommendations');


// Show the form for creating a new category
Route::get('category/create', [CategoryController::class, 'create'])->name('categories.create');

// Store the newly created category
Route::post('category/store', [CategoryController::class, 'store'])->name('categories.store');

// List all categories
Route::get('categories', [CategoryController::class, 'index'])->name('categories.index');
//deleting a catagory
Route::delete('/categories/{category}', [CategoryController::class, 'destroy'])->name('categories.destroy');
// In routes/web.php
Route::get('events/{id}', [EventController::class, 'show'])->name('events.show');


Route::get('/logout',[AuthManager::class,'logout'],)->name('logout');