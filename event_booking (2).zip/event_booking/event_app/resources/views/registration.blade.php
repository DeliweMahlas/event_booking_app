@extends("layout")
@section("title", "Register")

@section("content")
<div class="container mt-5">
    <h2>Register</h2>
    <form action="{{ route('registration.post') }}" method="POST" style="max-width: 400px; margin: auto;">
        @csrf
        
        
        <div class="mb-3">
            <label for="name" class="form-label">Name</label>
            <input type="text" name="name" class="form-control" id="name" required>
        </div>

       
        <div class="mb-3">
            <label for="email" class="form-label">Email address</label>
            <input type="email" name="email" class="form-control" id="email" required>
        </div>

    
        <div class="mb-3">
            <label for="password" class="form-label">Password</label>
            <input type="password" name="password" class="form-control" id="password" required>
        </div>

        <!-- Role Field -->
        <div class="mb-3">
            <label for="role" class="form-label">Role</label>
            <select name="role" id="role" class="form-select" required>
                <option value="user">User</option>
                <option value="admin">Admin</option>
                <option value="organizer">Organizer</option>
            </select>
        </div>

        
        <button type="submit" class="btn btn-primary">Register</button>
    </form>
</div>

<style>
    .container {
        background-color: #f8f9fa;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.1);
        margin-top: 50px; 
    }

    h2 {
        margin-bottom: 20px;
        text-align: center;
    }

    .form-control, .form-select {
        padding: 8px;
        font-size: 0.9rem;
        border-radius: 4px;
        border: 1px solid #ced4da;
    }

    .form-control:focus, .form-select:focus {
        border-color: #80bdff;
        box-shadow: 0 0 5px rgba(0, 123, 255, 0.25);
    }

    .btn-primary {
        width: 100%;
        padding: 8px;
        font-size: 1rem;
        background-color: #007bff;
        border: none;
        border-radius: 4px;
        transition: background-color 0.3s ease;
    }

    .btn-primary:hover {
        background-color: #0056b3;
    }
</style>
@endsection
