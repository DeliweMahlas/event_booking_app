<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to Event Booking</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background-image: url('{{ asset('images/jason-leung-Xaanw0s0pMk-unsplash.jpg') }}');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }
        .container {
            text-align: center;
            padding: 20px;
            border-radius: 10px;
            color: white; /* Set text color to white for better visibility */
        }
        h1 {
            color: white; /* Set heading color to white */
        }
        p {
            color: white; /* Set paragraph color to white */
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: orange;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            margin: 10px;
        }
        .btn:hover {
            background-color: darkorange;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Welcome to the Event Booking Platform</h1>
        <p>Book your next event quickly and easily!</p>
        
        <!-- Register Button -->
        <a href="{{ route('registration') }}" class="btn">Register</a>
        
        <!-- Login Button -->
        <a href="{{ route('login') }}" class="btn">Login</a>
    </div>
</body>
</html>
