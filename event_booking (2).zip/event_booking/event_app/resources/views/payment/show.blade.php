<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment</title>
</head>
<body>
    <h1>Complete Your Payment</h1>
    <form method="POST" action="{{ route('payment.process', $booking->id) }}">
        @csrf
        <!-- Payment form fields (e.g., Stripe Elements) -->
        <button type="submit">Pay Now</button>
    </form>
</body>
</html>
