<?php

namespace App\Http\Controllers;

use App\Models\Event;
use Illuminate\Support\Facades\Auth;
use App\Models\Category;
use Illuminate\Http\Request;

class EventController extends Controller
{
    public function index()
    {
        $events = Event::with('category', 'organizer')->get();
        return view('events.index', compact('events'));
    }

    public function show($id)
    {
        $event = Event::find($id);
        return view('events.show', compact('event'));
    }

    public function create()
    {
        $categories = Category::all();
        return view('events.create', compact('categories'));
    }

    public function store(Request $request)
    {
        // Validate the incoming request data
        $validatedData = $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'required|string',
            'location' => 'required|string',
            'date' => 'required|date',
            'time' => 'required|date_format:H:i',
            'category_id' => 'required|exists:categories,id',
            'max_attendees' => 'required|integer',
            'ticket_price' => 'required|numeric',
            'status' => 'required|in:upcoming,ongoing,completed', // Ensure correct casing
            'visibility' => 'required|in:public,private', // Ensure correct casing
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048', // Validation rule for the image
        ]);
    
        // Ensure the user is authenticated
        $user = Auth::user();
        if (!$user) {
            return redirect()->route('events.index')->with('error', 'You must be logged in to create an event.');
        }
    
        // Set the organizer_id to the authenticated user's ID
        $validatedData['organizer_id'] = $user->id;
    
        // Handle the image upload
        if ($request->hasFile('image')) {
            $imagePath = $request->file('image')->store('public/events');
            $validatedData['image'] = basename($imagePath); // Store the file name only
        }
    
        // Create the event
        Event::create($validatedData);
    
        // Redirect back with a success message
        return redirect()->route('events.create')->with('success', 'Event created successfully!');
    }
    }

