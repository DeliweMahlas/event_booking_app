<?php

// app/Http/Controllers/BookingController.php
namespace App\Http\Controllers;

use App\Models\Event;
use App\Models\Booking;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Stripe\Stripe;
use Stripe\PaymentIntent;

class BookingController extends Controller
{
    public function showBookingForm($eventId)
    {
        $event = Event::findOrFail($eventId);
        return view('bookings.create', compact('event'));
    }

    public function store(Request $request, $eventId)
    {
        $user = Auth::user();
        $event = Event::find($eventId);

        // Calculate the total amount based on the number of tickets
        $numberOfTickets = $request->input('number_of_tickets');
        $totalAmount = $event->ticket_price * $numberOfTickets;

        // Create a booking record with 'pending' payment status
        $booking = Booking::create([
            'user_id' => $user->id,
            'event_id' => $event->id,
            'number_of_tickets' => $numberOfTickets,
            'amount_paid' => $totalAmount,
            'payment_status' => 'pending', // Payment status will be updated after payment
        ]);

        // Redirect to payment process (e.g., Stripe, PayPal)
        return redirect()->route('payment.checkout', $booking->id);
    }
}
