<?php

namespace App\Http\Controllers;


use App\Models\user;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;

class AuthManager extends Controller
{
    function login()
    {
       
        return view('login');
    }

    function registration()
    {
        
        return view('registration');
    }


    function loginPost(Request $request)
    {
        $request ->validate([
            'email' => 'required',
            'password' => 'required'
        ]);

        $credentials = $request->only('email','password');
        if(Auth::attempt($credentials))
        {
            $user = Auth::user();
            if($user->role == 'user'){
                return redirect()->route('user.userpage');
            }else if($user->role==='organizer')
            {
                return redirect()->route('home');
            }else{
                return redirect()->route(('admin.dashboard'));
            }
           
        }
        return redirect(route('login'))->with("error","");
    }

    function registrationPost(Request $request)
    {
        $request ->validate([
            'name' => 'required',
            'email' => 'required|email|unique:users',
            'password' => 'required',
            'role' => 'required'
        ]);

        $data['name'] = $request-> name;
        $data['email'] = $request-> email;
        $data['password'] = Hash::make($request-> password);
        $data['role'] = $request-> role;
        $user = user::create($data);

        if(!$user)
        {
            return redirect(route('registration'))->with("error","Registration failed, try again");
        }
        return redirect(route('login'))->with("success","");
    }

    function logout()
    {
        Auth::logout();
    return redirect('/'); // Redirect to home or login page
    }
}
