<?php

namespace App\Http\Controllers;

use App\Models\Booking;
use Illuminate\Http\Request;
use Stripe\PaymentIntent;
use Stripe\Stripe;

class PaymentController extends Controller
{
    public function show(Booking $booking)
    {
       
        $booking->load('event');
        
        
        $clientSecret = $this->getStripeClientSecret($booking);
    
        
        return view('payment.checkout', [
            'booking' => $booking,
            'clientSecret' => $clientSecret
        ]);
    }
    private function getStripeClientSecret(Booking $booking)
    {
        Stripe::setApiKey(env('STRIPE_SECRET'));
    
        // Ensure the amount is at least the minimum allowed
        $amountInCents = max($booking->amount_paid * 100, 5000); // Example: 5000 cents ($50) as a minimum
    
        $paymentIntent = PaymentIntent::create([
            'amount' => $amountInCents,
            'currency' => 'usd',
            'metadata' => [
                'booking_id' => $booking->id
            ]
        ]);
    

    return $paymentIntent->client_secret;
}

   

    public function process(Request $request, $bookingId)
    {
        $booking = Booking::findOrFail($bookingId);
        
        // Process payment (e.g., with Stripe API)
        
        // Update booking payment status
        $booking->update(['payment_status' => 'completed']);
        
        return redirect()->route('booking.history')->with('success', 'Payment successful!');
    }
}
