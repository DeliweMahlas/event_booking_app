<!-- resources/views/bookings/create.blade.php -->


<?php $__env->startSection('title', 'Book Tickets'); ?>

<?php $__env->startSection('content'); ?>
    <main class="booking-page">
    <h2><?php echo e($event->name); ?></h2>
<p><?php echo e($event->description); ?></p>
<p>Price per ticket: $<?php echo e($event->ticket_price); ?></p>

<form action="<?php echo e(route('events.book', $event->id)); ?>" method="POST">
  <?php echo csrf_field(); ?>
  <div class="form-group">
    <label for="number_of_tickets">Number of Tickets</label>
    <input type="number" name="number_of_tickets" min="1" max="<?php echo e($event->max_attendees); ?>" value="1" required>
  </div>
  <button type="submit" class="btn btn-primary">Book Tickets</button>
</form> 

<?php $__env->stopSection(); ?>

<style>
    .booking-page {
        padding: 20px;
    }

    .container {
        max-width: 600px;
        margin: 0 auto;
    }

    .event-details {
        margin-bottom: 20px;
    }

    .form-group {
        margin-bottom: 20px;
    }

    .btn-primary {
        background-color: #007bff;
        color: #ffffff;
        padding: 10px 20px;
        border-radius: 5px;
        border: none;
        cursor: pointer;
    }

    .btn-primary:hover {
        background-color: #0056b3;
    }
</style>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\htdocs56\htdocs\event_booking\event_app\resources\views/events/show.blade.php ENDPATH**/ ?>