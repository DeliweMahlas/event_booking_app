<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid" style="background-color: aqua;">
    <a class="navbar-brand" href="#">Event Booking</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <ul class="navbar-nav">
       

        <?php if(auth()->guard()->guest()): ?>

        <li class="nav-item">
          <a class="nav-link active" aria-current="page"href="<?php echo e(route('registration')); ?>">Register</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="<?php echo e(route('login')); ?>">Login</a>
        </li>
       
        <?php else: ?>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page"><?php echo e(Auth::user()->name); ?>.</a>
        </li>
        <?php if(Auth::user()->role == 'user'): ?>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('user.userpage')); ?>">User Dashboard</a>
        </li>
        <?php elseif(Auth::user()->role == 'organizer'): ?>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="<?php echo e(route('home')); ?>">Home</a>
        </li>
        <?php elseif(Auth::user()->role == 'admin'): ?>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('admin.dashboard')); ?>">Admin Dashboard</a>
        </li>
        <?php endif; ?>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="<?php echo e(route('logout')); ?>">Logout</a>
        </li>
       
      
        <?php endif; ?>



        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Dropdown link
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="#">Logout</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>
<style>
 
.navbar {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  z-index: 1000;
  background-color: aqua; 
  box-shadow: aqua;
  transition: background-color 0.3s ease, box-shadow 0.3s ease;
}


.container-fluid {
  padding: 0;
}


body {
  padding-top: 70px; 
}


.navbar-brand {
  color: #333 !important; 
  font-weight: bold;
  font-size: 1.25rem;
  transition: color 0.3s ease;
}

.navbar-brand:hover {
  color: #333 !important; 
}


.nav-link {
  color: #000 !important; 
  font-weight: 500;
  font-size: 1rem;
  transition: color 0.3s ease, transform 0.3s ease;
}

.nav-link:hover {
  color: #333 !important; 
  transform: scale(1.05);
}


.navbar-toggler-icon {
  background-image: url('data:image/svg+xml;charset=utf8,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 30"%3E%3Cpath stroke="rgba(0,0,0,.5)" stroke-width="2" d="M5 8h20M5 15h20M5 22h20"/%3E%3C/svg%3E');
  transition: transform 0.3s ease;
}

.navbar-toggler:hover .navbar-toggler-icon {
  transform: rotate(90deg);
}


.navbar-nav {
  margin-left: auto;
}

/* Space between nav items */
.nav-item {
  margin-left: 1rem;
}


.nav-item.dropdown .dropdown-menu {
  background-color: aqua; 
  border: none;
  transition: background-color 0.3s ease;
}

.dropdown-item {
  color: #000; 
  transition: background-color 0.3s ease, color 0.3s ease;
}

.dropdown-item:hover {
  background-color: #00ced1;
  color: #000;
}

.dropdown-toggle::after {
  color: #000;
  transition: transform 0.3s ease;
}

.dropdown-toggle:hover::after {
  transform: rotate(180deg);
}
</style>
<?php /**PATH C:\Users\user\Desktop\htdocs56\htdocs\event_booking\event_app\resources\views/include/header.blade.php ENDPATH**/ ?>