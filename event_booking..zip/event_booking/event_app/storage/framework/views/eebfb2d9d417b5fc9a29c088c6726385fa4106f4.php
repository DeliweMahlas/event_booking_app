<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking History</title>
</head>
<body>
    <h1>My Bookings</h1>
    <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div>
            <p>Event: <?php echo e($booking->event->name); ?></p>
            <p>Date: <?php echo e($booking->event->date); ?></p>
            <p>Quantity: <?php echo e($booking->quantity); ?></p>
            <p>Status: <?php echo e($booking->payment_status); ?></p>
            <p>QR Code: <img src="<?php echo e($booking->qr_code); ?>" alt="QR Code"></p>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\myEventPage\my_first_app\resources\views/bookings/history.blade.php ENDPATH**/ ?>