<script src="https://js.stripe.com/v3/"></script>

<h2>Complete Your Payment</h2>
<p>Amount: R<?php echo e($booking->amount_paid); ?></p>

<form action="<?php echo e(route('bookings.history')); ?>" method="POST" id="payment-form">
                <?php echo csrf_field(); ?>
              
                <div id="card-element">
                    <!-- A Stripe Element will be inserted here. -->
                </div>
                
                <button type="submit" class="btn btn-primary">Pay Now</button>
                
                <input type="hidden" name="stripeToken" id="stripeToken">
            </form>
        </div>
    </main>
    
    <script src="https://js.stripe.com/v3/"></script>
    <script>
        var stripe = Stripe('<?php echo e(config('services.stripe.key')); ?>');
        var elements = stripe.elements();
        
        var card = elements.create('card');
        card.mount('#card-element');
        
        var form = document.getElementById('payment-form');
        form.addEventListener('submit', function(event) {
            event.preventDefault();
            
            stripe.createToken(card).then(function(result) {
                if (result.error) {
                    // Show error in payment form
                    console.error(result.error.message);
                } else {
                    // Insert the token ID into the form so it gets submitted to the server
                    document.getElementById('stripeToken').value = result.token.id;
                    form.submit();
                }
            });
        });
    </script>

<style>
    .booking-page {
        padding: 20px;
    }

    .container {
        max-width: 600px;
        margin: 0 auto;
    }

    .event-details {
        margin-bottom: 20px;
    }

    .form-group {
        margin-bottom: 20px;
    }

    .btn-primary {
        background-color: #007bff;
        color: #ffffff;
        padding: 10px 20px;
        border-radius: 5px;
        border: none;
        cursor: pointer;
    }

    .btn-primary:hover {
        background-color: #0056b3;
    }
</style><?php /**PATH C:\Users\user\Desktop\htdocs56\htdocs\event_booking\event_app\resources\views/payment/checkout.blade.php ENDPATH**/ ?>