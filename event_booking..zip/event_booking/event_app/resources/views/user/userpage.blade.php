@extends("layout")
@section("title", "Login")
@section("content")
    
    <div class="container">
        <h2>Upcoming Events User</h2>

        @foreach($events as $event)
            <div class="event-card">
                <div class="event-title">{{ $event->name }}</div>
                <div class="event-date">{{ $event->date->format('F j, Y') }}</div>
                <div class="event-description">{{ $event->description }}</div>
                <a href="{{ route('tickets.create', $event->id) }}" class="btn-buy">Buy Tickets</a>
            </div>
        @endforeach
    </div>

    @endsection
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        h2 {
            font-size: 24px;
            color: #333;
            margin-bottom: 20px;
        }
        .event-card {
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            background-color: #f9f9f9;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .event-title {
            font-size: 20px;
            font-weight: bold;
            color: #333;
            margin-bottom: 10px;
        }
        .event-date {
            color: #666;
            margin-bottom: 10px;
        }
        .event-description {
            margin-bottom: 20px;
        }
        .btn-buy {
            display: inline-block;
            padding: 10px 20px;
            color: #fff;
            background-color: #007bff;
            border: none;
            border-radius: 4px;
            text-decoration: none;
            text-align: center;
        }
        .btn-buy:hover {
            background-color: #0056b3;
        }
    </style>