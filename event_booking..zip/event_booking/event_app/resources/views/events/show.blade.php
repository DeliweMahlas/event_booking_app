<!-- resources/views/bookings/create.blade.php -->
@extends('layout')

@section('title', 'Book Tickets')

@section('content')
    <main class="booking-page">
    <h2>{{ $event->name }}</h2>
<p>{{ $event->description }}</p>
<p>Price per ticket: ${{ $event->ticket_price }}</p>

<form action="{{ route('events.book', $event->id) }}" method="POST">
  @csrf
  <div class="form-group">
    <label for="number_of_tickets">Number of Tickets</label>
    <input type="number" name="number_of_tickets" min="1" max="{{ $event->max_attendees }}" value="1" required>
  </div>
  <button type="submit" class="btn btn-primary">Book Tickets</button>
</form> 

@endsection

<style>
    .booking-page {
        padding: 20px;
    }

    .container {
        max-width: 600px;
        margin: 0 auto;
    }

    .event-details {
        margin-bottom: 20px;
    }

    .form-group {
        margin-bottom: 20px;
    }

    .btn-primary {
        background-color: #007bff;
        color: #ffffff;
        padding: 10px 20px;
        border-radius: 5px;
        border: none;
        cursor: pointer;
    }

    .btn-primary:hover {
        background-color: #0056b3;
    }
</style>
