<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment</title>
    <style>
    body {
            font-family: 'Helvetica Neue', Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        h1 {
            text-align: center;
            color: #333;
            font-size: 2rem;
            margin-bottom: 20px;
        }

        /* Container styles */
        .container {
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 500px;
        }

        /* Button styles */
        .btn {
            background-color: #ff8800; /* Orange color */
            border: none;
            padding: 15px 20px;
            font-size: 1rem;
            color: white;
            cursor: pointer;
            border-radius: 5px;
            width: 100%;
            text-transform: uppercase;
            transition: background-color 0.3s ease-in-out;
            display: inline-block;
            text-align: center;
        }

        .btn:hover {
            background-color: #e67800; /* Darker orange on hover */
        }

        /* Form styling */
        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        /* Responsive */
        @media (max-width: 600px) {
            .container {
                padding: 20px;
            }
            h1 {
                font-size: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <h1>Complete Your Payment</h1>
    <form method="POST" action="{{ route('payment.complete', $booking->id) }}">
        @csrf
        <!-- Payment form fields (e.g., Stripe Elements) -->
        <button type="submit">Pay Now</button>
    </form>
</body>
</html>
