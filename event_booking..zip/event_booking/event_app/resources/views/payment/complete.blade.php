<h2>Payment Successful!</h2>
<p>Your booking for {{ $event->name }} is confirmed.</p>
<p>Number of tickets: {{ $booking->number_of_tickets }}</p>
<p>Total amount paid: ${{ $booking->amount_paid }}</p>

<p>Your payment has been successfully processed. Enjoy the event!</p>
