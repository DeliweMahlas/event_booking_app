<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking History</title>
</head>
<body>
    <h1>My Bookings</h1>
    @foreach ($bookings as $booking)
        <div>
            <p>Event: {{ $booking->event->name }}</p>
            <p>Date: {{ $booking->event->date }}</p>
            <p>Quantity: {{ $booking->quantity }}</p>
            <p>Status: {{ $booking->payment_status }}</p>
            <p>QR Code: <img src="{{ $booking->qr_code }}" alt="QR Code"></p>
        </div>
    @endforeach
</body>
</html>
