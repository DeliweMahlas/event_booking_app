<!-- resources/views/bookings/manage.blade.php -->
@extends('layouts.app')

@section('content')
<div class="container">
    <h2>Your Bookings</h2>
    <table class="table">
        <thead>
            <tr>
                <th>Event</th>
                <th>Date</th>
                <th>Time</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($bookings as $booking)
            <tr>
                <td>{{ $booking->event->name }}</td>
                <td>{{ $booking->event->date->format('Y-m-d') }}</td>
                <td>{{ $booking->event->time }}</td>
                <td>{{ $booking->payment_status }}</td>
                <td>
                    <form action="{{ route('bookings.cancel', $booking->id) }}" method="POST">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger">Cancel</button>
                    </form>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection
